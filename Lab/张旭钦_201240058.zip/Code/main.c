#include <stdio.h>
#include <stdlib.h>

#include "intercode.h"
#include "logger.h"
#include "semantics.h"
extern ASTNode *ast_root;

extern void yyrestart(FILE *input_file);
extern int yyparse(void);
extern void print_AST();
extern void program_handler(ASTNode *root);
extern void translate_program(ASTNode *root, FILE *out);
extern int lexical_error;
extern int syntax_error;
// extern int yydebug;

int main(int argc, char **argv) {
    if (argc <= 2) {
        fprintf(stderr, "Usage: %s <input> <output>）\n", argv[0]);
        return 1;
    }
    FILE *in = fopen(argv[1], "r");
    FILE *out = fopen(argv[2], "w");
    if (!in || !out) {
        perror(argv[1]);
        return 1;
    }
    yyrestart(in);
    // yydebug = 1;
    yyparse();
    if (!lexical_error && !syntax_error) {
        // print_AST();
        program_handler(ast_root);
        translate_program(ast_root, out);
    }
    return 0;
}
