# set -e
# make lexical 
# echo "#### make lexical successfully ####"
# gcc -g main.c lex.yy.c -lfl -o scanner

# echo "#### BEGIN TEST1 ####"
# ./scanner ../Test/test1.cmm
# # echo "#### BEGIN TEST4(Hex test) ####"
# # ./scanner ../Test/test4.cmm
# echo "#### ./Test/test5.cmm"
# ./scanner ../Test/test5.cmm


flex -o ./lex.yy.c ./lexical.l
bison -o ./test_syntax.tab.c -d -v ./test_syntax.y
gcc -g -c ./test_syntax.tab.c -o ./test_syntax.tab.o
gcc -g -std=c99 -c -o main.o main.c
gcc -g -std=c99 -c -o test_syntax.tab.o test_syntax.tab.c
gcc -g -o parser ./main.o ./test_syntax.tab.o -lfl -ly

